require_relative "./Pieces/Rook.rb"
require_relative "./Pieces/Bishop.rb"
require_relative "./Pieces/Queen.rb"
require_relative "./Pieces/Knight.rb"
require_relative "./Pieces/Null.rb"
require_relative "./Pieces/Pawn.rb"
require_relative "./Pieces/King.rb"

