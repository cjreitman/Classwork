require_relative 'card'

class Deck

  # Returns an array of all 52 playing cards.
  def self.all_cards

  end

  # Initializes with all 52 cards by default
  def initialize(cards = Deck.all_cards)

  end

  def count

  end

  def take(n)

  end

  def deal_hand(player)

  end

  def empty?

  end
end
