class Player
  attr_reader :hand

  #Initializes with an empty hand by default
  def initialize(hand = [])

  end

  def take(cards)

  end

  def end_turn(deck)

  end

  def move_pile(start_pile, target_pile)

  end

  def play(card, pile)

  end

  def won?

  end
end
