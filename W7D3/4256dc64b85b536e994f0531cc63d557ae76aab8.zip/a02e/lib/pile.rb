class Pile
  attr_reader :corner
  attr_accessor :cards

  # Initializes as an empty regular pile by default
  def initialize(corner = false, cards = [])

  end

  def empty?

  end

  def top_card

  end

  def bottom_card

  end
  
  def valid_move?(card)

  end

  def move_all(to_pile)

  end

  def <<(card)
    cards << card
  end
end
