import React from 'react';

class BenchIndex extends React.Component {

  constructor(props) {
    super(props);
  }

  componentDidMount() {
     this.props.fetchbenches();
  }

  render() {
   
    const benches = this.props.benches.map( (bench) => {
      return (
        <div>
          <BenchIndex
        </div>
      )
    })   
    
    return <div>{benches}</div> 
    }
};

export default BenchIndex;