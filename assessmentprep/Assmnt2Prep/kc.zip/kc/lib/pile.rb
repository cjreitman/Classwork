class Pile
  attr_reader :top_card

  def initialize(top_card)
    @top_card = top_card
  end

  def current_value
    @top_card.value
  end

  def current_suit
    @top_card.suit
  end

  def valid_play?(pile_num, card)
    # if card is opposite color of current suit && card.value == current_value
      return true
    end
    return false
  end

  def play(card)
    raise 'invalid play' if !valid_play?(card)

    @top_card = card
    @current_suit = card.suit
  end

end