require_relative "card.rb"
class Deck

  def self.create_deck
    cards = []
    suits = Card.suits
    values = Card.values
    suits.each do |suit|
      values.each do |value|
        cards << Card.new(suit, value)
      end
    end
    cards
  end

  def initialize(cards = Deck.create_deck)

    @cards = cards

  end

  def count 
    return @cards.length
  end


  def take(n)
    taken = []
    if n <= @cards.count
      n.times do
        taken << @cards.shift
      end
    else
      raise "Not enough cards, booboo"
    end
    taken
  end

  def return(cards)
    @cards += cards
  end
end