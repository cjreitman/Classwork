require_relative './card'
require_relative './hand'

class Deck
  #What is this? What does it do?
  def self.all_cards
  end

  def initialize(cards = Deck.all_cards)
  end

  def deal_hand
  end

  def count
    @cards.count
  end

  def take(n)
  end

  def return(cards)
  end

  def shuffle
  end
end
